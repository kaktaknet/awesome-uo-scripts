// polRestart.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <process.h>	// for beginthreadex, etc.
#include <string>
#include <stdio.h>

#include <windows.h>
#include <COMMDLG.H>

int main(int argc, char* argv[])
{
	STARTUPINFO si;
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	PROCESS_INFORMATION pi;
	const char* m_server_path="pol.exe";
	if (argc>1) {
		m_server_path=argv[1];
	}
	int flags=CREATE_NEW_CONSOLE | NORMAL_PRIORITY_CLASS;
	if (argc>2) {
		flags =  CREATE_NO_WINDOW | NORMAL_PRIORITY_CLASS;
	}
	printf("Starting %s.\n",m_server_path);
	// Run POL
	//if(!CreateProcess(NULL,szFullName,NULL, NULL,TRUE,CREATE_SUSPENDED | NORMAL_PRIORITY_CLASS,
		
	if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
		&si, &pi))
	{
		printf("Failed to execute server\n");
		return 0;
	}
	if (argc<=2) {
		if(WaitForInputIdle(pi.hProcess, INFINITE) != 0)
		{
			printf("Failed waiting for server window to open. Attempting to restart server.\n");
			if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
				&si, &pi))
			{
				printf("Failed to execute server\n");
				return 0;
			}
			
		}
	}
	Sleep(1000);
	while (true) {
		//printf("Posting message.\n");
		
		// Post a message to the client thread
		if(PostThreadMessage(pi.dwThreadId, WM_USER, GetCurrentThreadId(), 0) == 0)
		{
			printf("Failed posting message to server. Attempting to restart server.\n");
			if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
				&si, &pi))
			{
				printf("Failed to execute server\n");
				return 0;
			}
			
		}
		/*printf("Recieving message.\n");
		MSG msg;
		// Wait for a message back from the client thread
		if(GetMessage(&msg, NULL, WM_USER, WM_USER) == -1)
		{
			printf("Failed waiting for message from server. Attempting to restart server.\n");
			if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
				&si, &pi))
			{
				printf("Failed to execute server\n");
				return 0;
			}
		
		}
		if(msg.wParam != 0)
		{
			printf("Bad message from server. Terminating server and attempting to restart it.\n");
			TerminateProcess(pi.hProcess, 0xffffffff);
			
			if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
				&si, &pi))
			{
				printf("Failed to execute server\n");
				return 0;
			}
			
		}*/
		//printf("Sleeping.\n");
		
		Sleep(1000);
	}	
	
	return 0;
}

