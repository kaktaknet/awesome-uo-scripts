// polRestart.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <string>
#include <stdio.h>

#include <windows.h>
#include <COMMDLG.H>
#include <process.h>	// for beginthreadex, etc.

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
//TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
//TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text

// Foward declarations of functions included in this code module:
//ATOM				MyRegisterClass(HINSTANCE hInstance);
//BOOL				InitInstance(HINSTANCE, int);
//LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
//LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int main(int argc, char* argv[])
{
 	STARTUPINFO si;
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	PROCESS_INFORMATION pi;
	const char* m_server_path="pol.exe";
	if (argc>1) {
		m_server_path=argv[1];
	}
	int flags=CREATE_NEW_CONSOLE | NORMAL_PRIORITY_CLASS;
	if (argc>2) {
		flags =  CREATE_NO_WINDOW | NORMAL_PRIORITY_CLASS;
	}
	printf("Starting %s.\n",m_server_path);
	// Run POL
	//if(!CreateProcess(NULL,szFullName,NULL, NULL,TRUE,CREATE_SUSPENDED | NORMAL_PRIORITY_CLASS,
		
	if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
		&si, &pi))
	{
		printf("Failed to execute server\n");
		return 0;
	}
	if (argc<=2) {
		if(WaitForInputIdle(pi.hProcess, INFINITE) != 0)
		{
			printf("Failed waiting for server window to open. Attempting to restart server.\n");
			if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
				&si, &pi))
			{
				printf("Failed to execute server\n");
				return 0;
			}
			
		}
	}
	Sleep(1000);
	while (true) {
		//printf("Posting message.\n");
		
		// Post a message to the client thread
		if(PostThreadMessage(pi.dwThreadId, WM_USER, GetCurrentThreadId(), 0) == 0)
		{
			printf("Failed posting message to server. Attempting to restart server.\n");
			if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
				&si, &pi))
			{
				printf("Failed to execute server\n");
				return 0;
			}
			
		}
		/*printf("Recieving message.\n");
		MSG msg;
		// Wait for a message back from the client thread
		if(GetMessage(&msg, NULL, WM_USER, WM_USER) == -1)
		{
			printf("Failed waiting for message from server. Attempting to restart server.\n");
			if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
				&si, &pi))
			{
				printf("Failed to execute server\n");
				return 0;
			}
		
		}
		if(msg.wParam != 0)
		{
			printf("Bad message from server. Terminating server and attempting to restart it.\n");
			TerminateProcess(pi.hProcess, 0xffffffff);
			
			if(!CreateProcess(m_server_path, NULL, NULL, NULL, FALSE, flags, NULL, NULL,
				&si, &pi))
			{
				printf("Failed to execute server\n");
				return 0;
			}
			
		}*/
		//printf("Sleeping.\n");
		
		Sleep(1000);
	}	
	
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	char* argv[] = {""};
	main(0, argv);
	return 0;
}					 

/*
//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_POLRESTART);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_POLRESTART;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR szHello[MAX_LOADSTRING];
	LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);

	switch (message) 
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code here...
			RECT rt;
			GetClientRect(hWnd, &rt);
			DrawText(hdc, szHello, strlen(szHello), &rt, DT_CENTER);
			EndPaint(hWnd, &ps);
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}
*/